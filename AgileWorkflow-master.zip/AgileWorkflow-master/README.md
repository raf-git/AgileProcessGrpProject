# AgileWorkflow
Setup for github actions workflow
